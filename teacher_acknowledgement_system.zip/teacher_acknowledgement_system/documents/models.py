import hashlib
from django.db import models
from django.conf import settings

class Document(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to='documents/')
    version = models.CharField(max_length=50, default='1.0')
    requires_signature = models.BooleanField(default=False)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='created_documents')
    created_at = models.DateTimeField(auto_now_add=True)
    hash = models.CharField(max_length=64, blank=True, null=True) # SHA256

    def save(self, *args, **kwargs):
        if self.file and not self.hash:
            sha256_hash = hashlib.sha256()
            for chunk in self.file.chunks():
                sha256_hash.update(chunk)
            self.hash = sha256_hash.hexdigest()
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.title} (v{self.version})"

class DocumentAcknowledgement(models.Model):
    STATUS_CHOICES = [
        ('PENDING', 'Pending'),
        ('VIEWED', 'Viewed'),
        ('ACKNOWLEDGED', 'Acknowledged'),
        ('SIGNED', 'Signed'),
    ]

    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name='acknowledgements')
    teacher = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='acknowledgements')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
    viewed_at = models.DateTimeField(null=True, blank=True)
    acknowledged_at = models.DateTimeField(null=True, blank=True)
    signature_file = models.ImageField(upload_to='signatures/', null=True, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(null=True, blank=True)
    receipt_pdf = models.FileField(upload_to='receipts/', null=True, blank=True)
    document_hash = models.CharField(max_length=64, blank=True, null=True) # SHA256 at time of acknowledgement

    class Meta:
        unique_together = ('document', 'teacher')

    def __str__(self):
        return f"{self.teacher.username} - {self.document.title} ({self.status})"
