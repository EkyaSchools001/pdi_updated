from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import DocumentViewSet, AcknowledgementViewSet

router = DefaultRouter()
router.register(r'docs', DocumentViewSet, basename='document')
router.register(r'acks', AcknowledgementViewSet, basename='acknowledgement')

urlpatterns = [
    path('', include(router.urls)),
]
