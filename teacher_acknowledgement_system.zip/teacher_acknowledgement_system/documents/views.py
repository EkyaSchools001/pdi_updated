from rest_framework import viewsets, permissions, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.utils import timezone
from django.contrib.auth import get_user_model
from accounts.permissions import IsAdmin, IsTeacher
from .models import Document, DocumentAcknowledgement
from .serializers import DocumentSerializer, DocumentAcknowledgementSerializer

User = get_user_model()

class DocumentViewSet(viewsets.ModelViewSet):
    queryset = Document.objects.all()
    serializer_class = DocumentSerializer

    def get_permissions(self):
        if self.action in ['list', 'retrieve']:
            return [permissions.IsAuthenticated()]
        return [IsAdmin()]

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    @action(detail=True, methods=['post'], permission_classes=[IsAdmin])
    def assign(self, request, pk=None):
        document = self.get_object()
        teacher_ids = request.data.get('teacher_ids', [])
        
        # Lock check: Optional business rule could be added here
        
        acks_created = 0
        for teacher_id in teacher_ids:
            try:
                teacher = User.objects.get(id=teacher_id, role='TEACHER')
                _, created = DocumentAcknowledgement.objects.get_or_create(
                    document=document,
                    teacher=teacher
                )
                if created:
                    acks_created += 1
            except User.DoesNotExist:
                continue
                
        return Response({'message': f'Document assigned to {acks_created} teachers.'}, status=status.HTTP_201_CREATED)

class AcknowledgementViewSet(viewsets.ModelViewSet):
    serializer_class = DocumentAcknowledgementSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role == 'ADMIN':
            return DocumentAcknowledgement.objects.all()
        return DocumentAcknowledgement.objects.filter(teacher=user)

    @action(detail=True, methods=['post'])
    def view_doc(self, request, pk=None):
        ack = self.get_object()
        if ack.status == 'PENDING':
            ack.status = 'VIEWED'
            ack.viewed_at = timezone.now()
            ack.save()
        return Response({'message': 'Status updated to VIEWED'})

    @action(detail=True, methods=['post'])
    def acknowledge(self, request, pk=None):
        ack = self.get_object()
        if ack.status in ['VIEWED', 'PENDING']:
            ack.status = 'ACKNOWLEDGED'
            ack.acknowledged_at = timezone.now()
            ack.ip_address = request.META.get('REMOTE_ADDR')
            ack.user_agent = request.META.get('HTTP_USER_AGENT')
            ack.document_hash = ack.document.hash
            ack.save()
            
            # TODO: Generate receipt
            return Response({'message': 'Document acknowledged'})
        return Response({'error': 'Cannot acknowledge in current status'}, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'])
    def sign(self, request, pk=None):
        ack = self.get_object()
        signature_base64 = request.data.get('signature')
        
        # Check if signing is allowed
        can_sign = False
        if ack.status == 'ACKNOWLEDGED':
            can_sign = True
        elif not ack.document.requires_signature and ack.status in ['VIEWED', 'PENDING']:
            can_sign = True
            
        if can_sign:
            from .utils import save_base64_signature, generate_receipt_pdf
            
            if signature_base64:
                save_base64_signature(ack, signature_base64)
            
            ack.status = 'SIGNED'
            ack.save()
            
            # Generate receipt after signing
            generate_receipt_pdf(ack)
            
            return Response({'message': 'Document signed and receipt generated'})
        return Response({'error': 'Cannot sign in current status'}, status=status.HTTP_400_BAD_REQUEST)
