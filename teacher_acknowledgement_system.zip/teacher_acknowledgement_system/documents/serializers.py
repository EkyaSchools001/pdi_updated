from rest_framework import serializers
from .models import Document, DocumentAcknowledgement
from accounts.serializers import UserSerializer

class DocumentSerializer(serializers.ModelSerializer):
    created_by_detail = UserSerializer(source='created_by', read_only=True)
    
    class Meta:
        model = Document
        fields = ('id', 'title', 'description', 'file', 'version', 'requires_signature', 
                  'created_by', 'created_by_detail', 'created_at', 'hash')
        read_only_fields = ('created_by', 'hash')

class DocumentAcknowledgementSerializer(serializers.ModelSerializer):
    document_detail = DocumentSerializer(source='document', read_only=True)
    teacher_detail = UserSerializer(source='teacher', read_only=True)
    
    class Meta:
        model = DocumentAcknowledgement
        fields = ('id', 'document', 'document_detail', 'teacher', 'teacher_detail', 
                  'status', 'viewed_at', 'acknowledged_at', 'signature_file', 
                  'ip_address', 'user_agent', 'receipt_pdf', 'document_hash')
        read_only_fields = ('viewed_at', 'acknowledged_at', 'receipt_pdf', 'document_hash')
