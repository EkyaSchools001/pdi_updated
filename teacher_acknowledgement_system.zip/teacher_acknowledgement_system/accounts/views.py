from django.contrib.auth import get_user_model
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .serializers import UserSerializer

User = get_user_model()

from accounts.permissions import IsAdmin, IsTeacher

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_user_profile(request):
    serializer = UserSerializer(request.user)
    return Response(serializer.data)

@api_view(['GET'])
@permission_classes([IsAdmin])
def list_teachers(request):
    teachers = User.objects.filter(role='TEACHER')
    serializer = UserSerializer(teachers, many=True)
    return Response(serializer.data)
